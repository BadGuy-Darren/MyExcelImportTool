package com.darren.tools.getexcelutil.exceptions;

public class SheetNoOuntOfBoundsException extends RuntimeException {

    public SheetNoOuntOfBoundsException(String message) {
        super(message);
    }

}
