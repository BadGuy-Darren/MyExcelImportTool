package com.darren.tools.getexcelutil.exceptions;

public class IllegalStatementsException extends Exception {

    public IllegalStatementsException(String message) {
        super(message);
    }

}
