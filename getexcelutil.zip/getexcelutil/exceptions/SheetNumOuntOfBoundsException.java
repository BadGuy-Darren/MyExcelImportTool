package com.darren.tools.getexcelutil.exceptions;

public class SheetNumOuntOfBoundsException extends RuntimeException {

    public SheetNumOuntOfBoundsException(String message) {
        super(message);
    }

}
