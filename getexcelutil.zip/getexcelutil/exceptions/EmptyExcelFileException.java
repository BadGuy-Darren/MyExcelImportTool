package com.darren.tools.getexcelutil.exceptions;

public class EmptyExcelFileException extends RuntimeException {

    public EmptyExcelFileException(String message) {
        super(message);
    }

}
